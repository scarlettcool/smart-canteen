
import { ErrorCode } from './service';

export interface UnifiedResponse<T> {
  ok: boolean;
  data?: T;
  message?: string;
  errorCode?: ErrorCode;
  traceId?: string;
  rawCode?: number | string;
}

// 契约 A: Standard Result (success/data)
interface EnvelopeA<T> {
  success: boolean;
  data: T;
  message?: string;
  errorCode?: ErrorCode;
}

// 契约 B: Legacy/Common Code (code/data/message)
interface EnvelopeB<T> {
  code: number;
  data: T;
  message?: string;
  traceId?: string;
}

class ApiClient {
  private static instance: ApiClient;
  private constructor() {}

  static getInstance(): ApiClient {
    if (!ApiClient.instance) ApiClient.instance = new ApiClient();
    return ApiClient.instance;
  }

  private generateRequestId(): string {
    return crypto.randomUUID();
  }

  // 映射逻辑严格遵守 h5-error-state-machine.md
  private mapRawCodeToErrorCode(code: number | string): ErrorCode {
    const codeStr = String(code);
    const mapping: Record<string, ErrorCode> = {
      '401': 'UNAUTHORIZED',
      '10001': 'UNAUTHORIZED',
      '10002': 'FORBIDDEN',
      '20001': 'E001', // 余额不足
      '30001': 'E3001', // 预约已满
      '429': 'DUPLICATE_SUBMIT',
      '500': 'SERVER_ERROR',
    };
    return mapping[codeStr] || 'SERVER_ERROR';
  }

  async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<UnifiedResponse<T>> {
    const token = localStorage.getItem('auth_token');
    const headers = new Headers(options.headers);
    
    if (token) headers.set('Authorization', `Bearer ${token}`);
    
    // 幂等性：针对 mutating 操作注入 X-Request-Id
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(options.method || '')) {
      if (!headers.has('X-Request-Id')) {
        headers.set('X-Request-Id', this.generateRequestId());
      }
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s 超时

      const response = await fetch(endpoint, {
        ...options,
        headers,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        if (response.status === 401) return { ok: false, errorCode: 'UNAUTHORIZED' };
        if (response.status === 403) return { ok: false, errorCode: 'FORBIDDEN' };
        if (response.status === 429) return { ok: false, errorCode: 'DUPLICATE_SUBMIT' };
        return { ok: false, errorCode: 'SERVER_ERROR', message: `HTTP ${response.status}` };
      }

      const rawData = await response.json();
      
      // 封包适配逻辑
      if ('success' in rawData) {
        const envA = rawData as EnvelopeA<T>;
        return {
          ok: envA.success,
          data: envA.data,
          message: envA.message,
          errorCode: envA.errorCode
        };
      }

      if ('code' in rawData) {
        const envB = rawData as EnvelopeB<T>;
        const isSuccess = envB.code === 0 || envB.code === 200;
        return {
          ok: isSuccess,
          data: envB.data,
          message: envB.message,
          traceId: envB.traceId,
          rawCode: envB.code,
          errorCode: isSuccess ? undefined : this.mapRawCodeToErrorCode(envB.code)
        };
      }

      return { ok: true, data: rawData as T };

    } catch (error: any) {
      if (error.name === 'AbortError') return { ok: false, errorCode: 'TIMEOUT' };
      return { ok: false, errorCode: 'NET_ERROR' };
    }
  }
}

export const apiClient = ApiClient.getInstance();
