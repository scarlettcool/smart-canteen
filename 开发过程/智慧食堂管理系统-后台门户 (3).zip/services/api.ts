
import { ApiResponse } from '../types';

/**
 * Generate a unique request ID for idempotency
 */
export const generateRequestId = () => {
  return 'req-' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

/**
 * Standard Error Code Mapping (Contract Aligned)
 */
const ERROR_CODE_MAP: Record<number, string> = {
  40001: '请求参数校验失败，请检查输入',
  40100: '会话已过期，请重新登录',
  40300: '权限不足，无法执行该操作',
  40400: '请求的资源不存在',
  40901: '数据冲突：工号或关键字段已存在',
  40902: '重复提交：该操作正在处理中',
  50000: '服务器内部错误，请稍后重试',
  10001: '余额不足 (E001)',
  30001: '预约已满 (E3001)',
};

export class ApiService {
  private static async request<T>(
    path: string, 
    method: string, 
    body?: any, 
    options: { idempotent?: boolean } = {}
  ): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${localStorage.getItem('token') || 'mock-token'}`,
    };

    if (options.idempotent) {
      headers['X-Request-Id'] = generateRequestId();
    }

    // Mock implementation for demo/dev purposes
    console.debug(`[API] ${method} ${path}`, { headers, body });
    
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simple mock success logic
        const success = true; 
        if (success) {
          resolve({
            code: 0,
            message: 'success',
            data: {} as T,
            traceId: generateRequestId()
          } as unknown as T);
        } else {
          const errorCode = 40300;
          reject({
            code: errorCode,
            message: ERROR_CODE_MAP[errorCode] || '未知错误',
            traceId: generateRequestId()
          });
        }
      }, 600);
    });
  }

  static get<T>(path: string) {
    return this.request<ApiResponse<T>>(path, 'GET');
  }

  static post<T>(path: string, body: any, idempotent = true) {
    return this.request<ApiResponse<T>>(path, 'POST', body, { idempotent });
  }

  static put<T>(path: string, body: any) {
    return this.request<ApiResponse<T>>(path, 'PUT', body);
  }

  static delete<T>(path: string) {
    return this.request<ApiResponse<T>>(path, 'DELETE');
  }
}
