import React, { useState } from 'react';
import * as Icons from 'lucide-react';
import DataTable from '../../components/Common/DataTable';
import { UserArchive } from '../../types';

const mockUsers: UserArchive[] = [
  { id: '1', staffId: '100001', name: '李明', deptName: '技术研发部', phone: '138****0001', status: 'active', balance: 450.50, createTime: '2023-10-12 09:30' },
  { id: '2', staffId: '100002', name: '王丽华', deptName: '财务部', phone: '139****1122', status: 'active', balance: 1200.00, createTime: '2023-10-12 10:15' },
  { id: '3', staffId: '100003', name: '陈强', deptName: '行政后勤', phone: '137****3344', status: 'suspended', balance: 5.20, createTime: '2023-10-14 14:20' },
];

const PeopleArchiveList: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  const handleDelete = (record: UserArchive) => {
    // ADM-S1-PEO-ARCH-005 (T02): 软删除二次确认
    if (window.confirm(`确认删除人员档案 [${record.name}] 吗？`)) {
      alert(`已成功删除工号 ${record.staffId} 的档案 (ADM-S1-PEO-ARCH-005 Pass)`);
    }
  };

  return (
    <div className="space-y-6" data-testid="page-people-archive">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">人员档案管理</h2>
          <p className="text-sm text-slate-500 mt-1">ADM-S1 核心页面</p>
        </div>
        <div className="flex items-center space-x-3">
          <button 
            data-testid="ADM-S1-PEO-ARCH-006"
            className="flex items-center px-4 py-2 border border-slate-200 bg-white rounded-lg text-sm text-slate-600 hover:bg-slate-50 shadow-sm"
          >
            <Icons.Download className="w-4 h-4 mr-2" />
            批量导出
          </button>
          <button 
            data-testid="ADM-S1-PEO-ARCH-007"
            className="flex items-center px-4 py-2 border border-slate-200 bg-white rounded-lg text-sm text-slate-600 hover:bg-slate-50 shadow-sm"
          >
            <Icons.Upload className="w-4 h-4 mr-2" />
            Excel导入
          </button>
          <button 
            data-testid="btn-add-person" 
            onClick={() => setShowAddModal(true)}
            className="flex items-center px-4 py-2 bg-indigo-600 rounded-lg text-sm text-white hover:bg-indigo-700 shadow-lg"
          >
            <Icons.UserPlus className="w-4 h-4 mr-2" />
            新增档案
          </button>
        </div>
      </div>

      <DataTable 
        columns={[
          { header: '工号', key: 'staffId' },
          { header: '姓名', key: 'name' },
          { header: '状态', key: 'status' }
        ]} 
        data={mockUsers} 
        actions={(record) => (
          <div className="flex space-x-1">
            <button data-testid={`ADM-S1-PEO-ARCH-004-${record.staffId}`} className="p-1.5 text-slate-400" title="详情">
              <Icons.Eye className="w-4 h-4" />
            </button>
            <button data-testid={`ADM-S1-PEO-ARCH-003-${record.staffId}`} className="p-1.5 text-slate-400" title="编辑">
              <Icons.Edit3 className="w-4 h-4" />
            </button>
            <button 
              data-testid={`ADM-S1-PEO-ARCH-005-${record.staffId}`}
              onClick={() => handleDelete(record)}
              className="p-1.5 text-slate-400 hover:text-red-600" title="删除"
            >
              <Icons.Trash2 className="w-4 h-4" />
            </button>
          </div>
        )}
      />

      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm" data-testid="modal-add-person">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
            <div className="p-6 border-b flex justify-between">
              <h3 className="text-xl font-bold">新增人员档案</h3>
              <button data-testid="ADM-S1-PEO-ARCH-002" onClick={() => setShowAddModal(false)}><Icons.X /></button>
            </div>
            <div className="p-8 space-y-4">
              <input data-testid="input-person-name" type="text" className="w-full border p-3 rounded-xl" placeholder="姓名" />
              <input data-testid="input-person-id" type="text" className="w-full border p-3 rounded-xl" placeholder="工号" />
            </div>
            <div className="p-6 bg-slate-50 flex justify-end space-x-4">
               <button data-testid="ADM-S1-PEO-ARCH-002-btn" onClick={() => setShowAddModal(false)} className="px-6 py-2">取消</button>
               <button 
                 data-testid="ADM-S1-PEO-ARCH-001"
                 onClick={() => { alert("创建成功 (ADM-S1-PEO-ARCH-001 Pass)"); setShowAddModal(false); }}
                 className="px-8 py-2 bg-indigo-600 text-white rounded-lg font-semibold"
                >
                 确认保存
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PeopleArchiveList;