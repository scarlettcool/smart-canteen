
import React, { useState, useMemo } from 'react';
import * as Icons from 'lucide-react';
import DataTable from '../../components/Common/DataTable';
import PermissionGuard from '../../components/Auth/PermissionGuard';
import { ApiService } from '../../services/api';
import { UserArchive } from '../../types';

const AccountManagement: React.FC = () => {
  const [processing, setProcessing] = useState(false);
  const [selectedUser, setSelectedUser] = useState<UserArchive | null>(null);
  const [adjustModal, setAdjustModal] = useState(false);
  const [adjustType, setAdjustType] = useState<'recharge' | 'deduction'>('recharge');
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const [accounts, setAccounts] = useState<UserArchive[]>([
    { id: '1', staffId: '1001', name: '张晓明', deptName: '研发部', phone: '13800000001', status: 'active', balance: 500.25, createTime: '2024-01-01' },
    { id: '2', staffId: '1002', name: '李丽', deptName: '财务部', phone: '13800000002', status: 'suspended', balance: 12.00, createTime: '2024-01-02' },
    { id: '3', staffId: '1003', name: '陈强', deptName: '行政部', phone: '13800000003', status: 'active', balance: 0.00, createTime: '2024-01-03' },
  ]);

  const filteredData = useMemo(() => {
    return accounts.filter(acc => 
      acc.name.includes(searchQuery) || acc.staffId.includes(searchQuery)
    );
  }, [accounts, searchQuery]);

  const handleAdjustSubmit = async () => {
    const val = parseFloat(amount);
    
    if (!amount || isNaN(val) || val <= 0) {
      alert("请输入有效的大于 0 的金额");
      return;
    }

    if (reason.trim().length < 5) {
      alert("请填写详细的调账原因 (不少于 5 字)");
      return;
    }

    if (adjustType === 'deduction' && selectedUser && val > selectedUser.balance) {
      alert(`余额不足！该账户当前余额为 ¥${selectedUser.balance.toFixed(2)}，无法扣款 ¥${val.toFixed(2)}`);
      return;
    }

    setProcessing(true); 

    try {
      // Calling centralized API service with X-Request-Id (Idempotency)
      await ApiService.post(`/consume/accounts/${selectedUser?.id}/adjust`, {
        amount: adjustType === 'recharge' ? val : -val,
        reason: reason,
        type: adjustType
      });

      // Update local state on success (Mock refresh)
      setAccounts(prev => prev.map(acc => {
        if (acc.id === selectedUser?.id) {
          const delta = adjustType === 'recharge' ? val : -val;
          return { ...acc, balance: Math.max(0, acc.balance + delta) };
        }
        return acc;
      }));

      setAdjustModal(false);
      setAmount('');
      setReason('');
      alert("操作成功！审计流水已记录。");
    } catch (error: any) {
      alert(`操作失败: ${error.message || '未知错误'}`);
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-6" data-testid="page-account-management">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">账户余额管理</h2>
          <p className="text-sm text-slate-500 mt-1">资金流水对账与手动调账中心 (RBAC Protected)</p>
        </div>
        <div className="flex space-x-2">
           <div className="relative">
             <Icons.Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
             <input 
               type="text"
               placeholder="搜索工号/姓名..."
               value={searchQuery}
               onChange={(e) => setSearchQuery(e.target.value)}
               className="pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm w-64 focus:ring-2 focus:ring-indigo-500 outline-none"
             />
           </div>
        </div>
      </div>

      <DataTable 
        title="账户名录"
        columns={[
          { header: '工号', key: 'staffId' },
          { header: '姓名', key: 'name' },
          { header: '部门', key: 'deptName' },
          { 
            header: '余额', 
            key: 'balance', 
            render: (v, record: UserArchive) => (
              <span data-testid={`cell-balance-${record.staffId}`} className="font-mono font-bold text-indigo-600">
                ¥{v.toFixed(2)}
              </span>
            )
          },
          { 
            header: '状态', 
            key: 'status',
            render: (v) => v === 'active' ? 
              <span className="bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded text-[10px] font-bold">正常</span> : 
              <span className="bg-rose-50 text-rose-600 px-2 py-0.5 rounded text-[10px] font-bold">冻结</span>
          }
        ]}
        data={filteredData}
        actions={(record: UserArchive) => (
          <div className="flex space-x-2">
            <button 
              data-testid={`btn-detail-${record.staffId}`}
              className="text-slate-400 hover:text-indigo-600"
              onClick={() => alert(`查看详情: ${record.name}`)}
            >
              <Icons.Eye className="w-4 h-4" />
            </button>
            
            {/* Permission Guard for sensitive Adjust action */}
            <PermissionGuard permission="CONSUME_ACCOUNT_ADJUST">
              <button 
                data-testid={`btn-adjust-${record.staffId}`}
                onClick={() => { setSelectedUser(record); setAdjustModal(true); }}
                className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-lg text-xs font-bold hover:bg-indigo-100 transition-colors"
              >
                调账
              </button>
            </PermissionGuard>
          </div>
        )}
      />

      {adjustModal && selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white p-8 rounded-3xl w-full max-w-md shadow-2xl animate-scaleIn">
            <div className="flex justify-between items-start mb-6">
              <h3 className="text-xl font-bold flex items-center">
                <Icons.ShieldCheck className="w-5 h-5 mr-2 text-indigo-600" />
                账户调账: {selectedUser.name}
              </h3>
              <button onClick={() => setAdjustModal(false)} className="text-slate-400 hover:text-slate-600">
                <Icons.X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="space-y-5">
              <div className="bg-slate-50 p-4 rounded-2xl flex justify-between items-center border border-slate-100">
                 <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">当前余额</span>
                 <span className="text-lg font-mono font-bold text-slate-700">¥{selectedUser.balance.toFixed(2)}</span>
              </div>

              <div className="flex p-1 bg-slate-100 rounded-2xl">
                <button 
                  data-testid="tab-recharge"
                  onClick={() => setAdjustType('recharge')}
                  className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all ${adjustType === 'recharge' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`}
                >手动充值</button>
                <button 
                  data-testid="tab-deduction"
                  onClick={() => setAdjustType('deduction')}
                  className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all ${adjustType === 'deduction' ? 'bg-white shadow-sm text-rose-600' : 'text-slate-500'}`}
                >手动扣款</button>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">调整金额</label>
                <div className="relative group">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold group-focus-within:text-indigo-600 transition-colors">¥</span>
                  <input 
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-slate-50 border border-transparent rounded-2xl pl-10 pr-4 py-4 text-lg font-mono outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-inner"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">原因说明 (审计记录)</label>
                <textarea 
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="请输入详细的业务原因，此操作将被记录在审计日志中..."
                  className="w-full bg-slate-50 border border-transparent rounded-2xl px-4 py-3 text-sm h-28 resize-none outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-inner"
                />
              </div>
            </div>

            <div className="flex gap-4 mt-8">
              <button 
                onClick={() => setAdjustModal(false)}
                className="flex-1 py-4 text-slate-400 font-bold text-sm hover:bg-slate-50 rounded-2xl transition-all"
              >取消</button>
              <button 
                data-testid="btn-submit-adjust"
                disabled={processing}
                onClick={handleAdjustSubmit}
                className={`flex-[2] py-4 rounded-2xl font-bold text-white shadow-lg transition-all flex items-center justify-center ${adjustType === 'recharge' ? 'bg-indigo-600 shadow-indigo-100 hover:bg-indigo-700' : 'bg-rose-600 shadow-rose-100 hover:bg-rose-700'} disabled:opacity-50`}
              >
                {processing ? <Icons.Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Icons.CheckCircle2 className="w-5 h-5 mr-2" />}
                {processing ? '正在提交...' : '确认执行'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccountManagement;
