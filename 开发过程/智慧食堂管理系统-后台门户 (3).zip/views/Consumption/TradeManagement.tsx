import React, { useState } from 'react';
import * as Icons from 'lucide-react';
import DataTable from '../../components/Common/DataTable';

const TradeManagement: React.FC = () => {
  const mockTrades = [
    { id: 'TX001', name: '张晓明', amount: -15.00, status: 'success', time: '2024-03-20 12:00' },
    { id: 'TX002', name: '李丽', amount: 50.00, status: 'corrected', time: '2024-03-20 12:05' },
  ];

  const handleCorrect = (id: string) => {
    const reason = window.prompt("冲正原因:");
    if (!reason) return;
    alert("冲正提交成功");
  };

  return (
    <div className="space-y-6" data-testid="page-trade-list">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">交易明细</h2>
        <input data-testid="input-trade-filter" type="text" placeholder="筛选..." className="border p-2 rounded" />
      </div>
      <DataTable 
        columns={[
          { header: '单号', key: 'id' },
          { header: '金额', key: 'amount' },
          { 
            header: '状态', 
            key: 'status',
            render: (v) => <span data-testid={`status-${v}`}>{v}</span>
          }
        ]}
        data={mockTrades}
        actions={(record) => (
          <div className="flex space-x-2">
            <button data-testid={`btn-trade-detail-${record.id}`} onClick={() => alert('详情')}>详情</button>
            <button 
              data-testid={`btn-trade-correct-${record.id}`}
              disabled={record.status === 'corrected'}
              onClick={() => handleCorrect(record.id)}
              className="text-orange-600 disabled:opacity-20"
            >冲正</button>
          </div>
        )}
      />
    </div>
  );
};

export default TradeManagement;