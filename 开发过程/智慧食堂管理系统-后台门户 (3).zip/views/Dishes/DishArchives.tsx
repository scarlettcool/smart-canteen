
import React from 'react';
import * as Icons from 'lucide-react';
import DataTable from '../../components/Common/DataTable';
import { Dish } from '../../types';

const mockDishes: Dish[] = [
  { id: 'D001', name: '宫保鸡丁', category: '热菜', price: 12.00, calories: 350, status: 'available', tags: ['辣', '推荐'] },
  { id: 'D002', name: '清炒菜心', category: '蔬菜', price: 6.00, calories: 120, status: 'available', tags: ['清淡'] },
  { id: 'D003', name: '红烧牛肉面', category: '面点', price: 18.00, calories: 550, status: 'sold_out', tags: ['招牌'] },
];

const DishArchives: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">菜品资料库</h2>
          <p className="text-sm text-slate-500 mt-1">管理菜品信息、营养成分及价格</p>
        </div>
        <button 
          data-testid="ADM-S3-DISH-ARCH-001"
          className="px-6 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-lg"
        >
          + 新增菜品
        </button>
      </div>

      <DataTable 
        columns={[
          { header: '菜品名称', key: 'name' },
          { header: '类别', key: 'category' },
          { header: '售价', key: 'price', render: (v) => <span className="font-mono font-bold text-slate-700">¥{v.toFixed(2)}</span> },
          { header: '热量', key: 'calories', render: (v) => <span>{v} kcal</span> },
          { 
            header: '状态', 
            key: 'status', 
            render: (v) => (
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${v === 'available' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                {v === 'available' ? '供应中' : '已售罄'}
              </span>
            )
          },
        ]}
        data={mockDishes}
        actions={(record) => (
          <div className="flex space-x-2">
            <button className="text-slate-400 hover:text-indigo-600"><Icons.Edit3 className="w-4 h-4" /></button>
            <button 
              data-testid={`ADM-S3-DISH-ARCH-002-${record.id}`}
              className="text-slate-400 hover:text-rose-600"
              onClick={() => alert(`菜品 ${record.name} 已下架`)}
            >
              <Icons.ArrowDownCircle className="w-4 h-4" />
            </button>
          </div>
        )}
      />
    </div>
  );
};

export default DishArchives;
